// تعریف تایپ های مختلف برای اکشن

export const ADD_TO_CURRNETS_LIST = "ADD_TO_CURRNETS_LIST";
export const CHANGE_THEME = "CHANGE_THEME";
